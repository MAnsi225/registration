
import UIKit

class ViewController: UIViewController {
    let obj=FormControls()
    var uname = UITextField()
    var mno = UITextField()
    var mail = UITextField()
    var pass = UITextField()
    var dob = UITextField()
    
    func createView()
    {   let nview=UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height))
        nview.backgroundColor=UIColor.gray
        self.view.addSubview(nview)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        createView()

        
        uname = obj.textFiled(frm: CGRect(x: 50 , y: 100, width: 200, height: 40), place: "Enter user name...", img: UIImage(named:"user.png"), ifrm: CGRect(x: 0, y: 0, width: 20, height: 20), keyboard: UIKeyboardType.alphabet, bgcolor: nil, borcolor: nil, tcolor: nil)
        self.view.addSubview(uname)
        
        mno = obj.textFiled(frm: CGRect(x: 50, y: 150, width: 200, height: 40), place: "Enter phone number...", img: UIImage(named: "phone.jpeg"), ifrm: CGRect(x: 0, y: 0, width: 20, height: 20), keyboard: UIKeyboardType.phonePad, bgcolor: nil, borcolor: nil, tcolor: nil)
        self.view.addSubview(mno)
    
        mail =  obj.textFiled(frm: CGRect(x: 50, y: 200, width: 200, height: 40), place: "Enter email address...", img: UIImage(named: "mail.jpeg"), ifrm: CGRect(x: 0, y: 0, width: 20, height: 20), keyboard: .emailAddress, bgcolor: nil, borcolor: nil, tcolor: nil)
        self.view.addSubview(mail)
        
        pass =  obj.textFiled(frm: CGRect(x: 50, y: 250, width: 200, height: 40), place: "Enter your password...", img: UIImage(named: "pass.jpeg"), ifrm: CGRect(x: 0, y: 0, width: 20, height: 20), keyboard: .default, bgcolor: nil, borcolor: nil, tcolor: nil)
        pass.isSecureTextEntry = true
        self.view.addSubview(pass)
        

        dob =  obj.textFiled(frm: CGRect(x: 50, y: 300, width: 200, height: 40), place: "Select your birthdate...", img: UIImage(named: "calender.png"), ifrm: CGRect(x: 0, y: 0, width: 20, height: 20), keyboard: .emailAddress, bgcolor: nil, borcolor: nil, tcolor: nil)
        dob.addTarget(self, action: #selector(self.date), for: .touchDown)
        self.view.addSubview(dob)

        
        let submit = obj.createbtn(frm: CGRect(x: 70, y: 350, width: 90, height: 30), title: "Submit", bcolor: UIColor.red)
        submit.addTarget(self, action: #selector(self.test), for: .touchUpInside)
        self.view.addSubview(submit)
        
        let reset = obj.createbtn(frm: CGRect(x: 200, y: 350, width: 90, height: 30), title: "Reset", bcolor: UIColor.red)
            reset.addTarget(self, action: #selector(self.test1), for: .touchUpInside)
        self.view.addSubview(reset)

    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func date(sender:UITextField)
    {
        let dt = UIDatePicker(frame: CGRect(x: 50, y: 300, width: 300, height: 100))
        dt.addTarget(self, action: #selector(self.selectdate), for: .valueChanged)
        dt.datePickerMode = .date
        dob.inputView = dt
        //self.view.addSubview(dt)
    }
    
    func selectdate(sender:UIDatePicker)
    {
        print("hjdsgfj")
    }
    
    func test(sender:UIButton)
    {
        print("hello")
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "next")
        self.navigationController?.pushViewController(stb!, animated: true)
    }

    func test1(sender:UIButton)
    {
        uname.text = ""
        mno.text = ""
        mail.text = ""
        pass.text = ""
        dob.text = ""
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
    }
    
}

